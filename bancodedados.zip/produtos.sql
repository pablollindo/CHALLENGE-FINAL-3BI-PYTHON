-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03/10/2025 às 07:28
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `produtos`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `carrinho`
--

CREATE TABLE `carrinho` (
  `id_item` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL DEFAULT 1,
  `preco_unitario` decimal(10,2) NOT NULL,
  `adicionado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `catalogo`
--

CREATE TABLE `catalogo` (
  `idProduto` int(7) NOT NULL,
  `nomeProduto` varchar(80) NOT NULL,
  `plataforma` varchar(20) NOT NULL,
  `categoria` varchar(30) NOT NULL,
  `sku` varchar(30) DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `estoqueAtual` int(11) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `catalogo`
--

INSERT INTO `catalogo` (`idProduto`, `nomeProduto`, `plataforma`, `categoria`, `sku`, `preco`, `estoqueAtual`, `ativo`) VALUES
(13, 'Spider-Man 2', 'PS5', 'Jogo Físico', 'PS5-SM2', 349.90, 0, 1),
(14, 'God of War', 'PS4', 'Jogo Físico', 'PS4-GOW', 199.90, 24, 1),
(15, 'Halo Infinite', 'Xbox Series', 'Jogo Físico', 'XBX-HALO', 299.90, 7, 1),
(16, 'Forza Horizon 5', 'Xbox One', 'Jogo Físico', 'XBO-FH5', 249.90, 16, 1),
(17, 'The Legend of Zelda: Tears of the Kingdom', 'Nintendo Switch', 'Jogo Físico', 'NSW-ZELDA', 329.90, 10, 1),
(18, 'Counter-Strike 2', 'PC', 'Jogo Digital', 'PC-CS2', 0.00, 999, 1),
(19, 'FIFA 24', 'PS5', 'Jogo Físico', 'PS5-FIFA24', 299.90, 20, 1),
(20, 'Call of Duty: Modern Warfare III', 'Xbox Series', 'Jogo Físico', 'XBX-COD', 349.90, 43, 1),
(21, 'Mario Kart 8 Deluxe', 'Nintendo Switch', 'Jogo Físico', 'NSW-MK8', 279.90, 12, 1),
(22, 'The Last of Us Part I', 'PS5', 'Jogo Físico', 'PS5-TLOU', 249.90, 0, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `historico_pagamentos`
--

CREATE TABLE `historico_pagamentos` (
  `id_pagamento` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `status` enum('pendente','aprovado','recusado','estornado') DEFAULT 'pendente',
  `valor` decimal(10,2) NOT NULL,
  `data_pagamento` timestamp NOT NULL DEFAULT current_timestamp(),
  `codigo_transacao` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `historico_pagamentos`
--

INSERT INTO `historico_pagamentos` (`id_pagamento`, `id_pedido`, `status`, `valor`, `data_pagamento`, `codigo_transacao`) VALUES
(1, 1, 'aprovado', 599.70, '2025-10-01 06:31:05', NULL),
(2, 2, 'aprovado', 499.80, '2025-10-01 06:33:41', NULL),
(3, 3, 'aprovado', 259.80, '2025-10-01 06:35:35', NULL),
(4, 4, 'aprovado', 499.80, '2025-10-01 06:37:56', NULL),
(5, 5, 'aprovado', 499.80, '2025-10-02 01:18:49', NULL),
(6, 6, 'aprovado', 559.80, '2025-10-02 01:36:09', NULL),
(7, 7, 'aprovado', 399.80, '2025-10-02 01:37:06', NULL),
(8, 8, 'aprovado', 1119.60, '2025-10-02 01:41:28', NULL),
(9, 9, 'aprovado', 2398.80, '2025-10-02 01:42:22', NULL),
(10, 10, 'aprovado', 599.80, '2025-10-02 01:43:25', NULL),
(11, 11, 'aprovado', 499.80, '2025-10-02 02:26:25', NULL),
(12, 12, 'aprovado', 1399.60, '2025-10-02 02:26:40', NULL),
(13, 13, 'aprovado', 14695.80, '2025-10-02 20:38:27', NULL),
(14, 14, 'aprovado', 3848.90, '2025-10-02 21:14:54', NULL),
(15, 15, 'aprovado', 899.70, '2025-10-03 04:00:29', NULL),
(16, 16, 'aprovado', 899.70, '2025-10-03 04:05:12', NULL),
(17, 17, 'aprovado', 1499.40, '2025-10-03 04:08:06', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_pedido`
--

CREATE TABLE `itens_pedido` (
  `id_item_pedido` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `itens_pedido`
--

INSERT INTO `itens_pedido` (`id_item_pedido`, `id_pedido`, `id_produto`, `quantidade`, `preco_unitario`, `subtotal`) VALUES
(1, 1, 11, 3, 199.90, 599.70),
(2, 2, 9, 2, 249.90, 499.80),
(3, 3, 8, 2, 129.90, 259.80),
(4, 4, 10, 2, 249.90, 499.80),
(5, 5, 10, 2, 249.90, 499.80),
(6, 6, 21, 2, 279.90, 559.80),
(7, 7, 14, 2, 199.90, 399.80),
(8, 8, 21, 4, 279.90, 1119.60),
(9, 9, 14, 12, 199.90, 2398.80),
(10, 10, 15, 2, 299.90, 599.80),
(11, 11, 16, 2, 249.90, 499.80),
(12, 12, 13, 4, 349.90, 1399.60),
(13, 13, 20, 42, 349.90, 14695.80),
(14, 14, 13, 11, 349.90, 3848.90),
(15, 15, 15, 3, 299.90, 899.70),
(16, 16, 19, 3, 299.90, 899.70),
(17, 17, 22, 6, 249.90, 1499.40);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `nome_produto` varchar(255) DEFAULT NULL,
  `numero_pedido` varchar(20) NOT NULL,
  `total_pedido` decimal(10,2) NOT NULL,
  `status` enum('pendente','processando','enviado','entregue','cancelado') DEFAULT 'pendente',
  `data_pedido` timestamp NOT NULL DEFAULT current_timestamp(),
  `forma_pagamento` enum('cartao_credito','cartao_debito','pix','boleto') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_cliente`, `nome_produto`, `numero_pedido`, `total_pedido`, `status`, `data_pedido`, `forma_pagamento`) VALUES
(9, 1, 'God of War (R$ 199.90)', 'PD202510012242228486', 2398.80, 'pendente', '2025-10-02 01:42:22', ''),
(10, 1, 'Halo Infinite (R$ 299.90)', 'PD202510012243250312', 599.80, 'pendente', '2025-10-02 01:43:25', ''),
(11, 1, 'Forza Horizon 5 (R$ 249.90)', 'PD202510012326259767', 499.80, 'pendente', '2025-10-02 02:26:25', 'cartao_credito'),
(12, 1, 'Spider-Man 2 (R$ 349.90)', 'PD202510012326401675', 1399.60, 'pendente', '2025-10-02 02:26:40', 'cartao_debito'),
(13, 1, 'Call of Duty: Modern Warfare III (R$ 349.90)', 'PD202510021738277536', 14695.80, 'pendente', '2025-10-02 20:38:27', 'cartao_debito'),
(14, 1, 'Spider-Man 2 (R$ 349.90)', 'PD202510021814548291', 3848.90, 'pendente', '2025-10-02 21:14:54', 'cartao_debito'),
(15, 1, 'Halo Infinite (R$ 299.90)', 'PD202510030100290158', 899.70, 'pendente', '2025-10-03 04:00:29', 'pix'),
(16, 1, 'FIFA 24 (R$ 299.90)', 'PD202510030105126934', 899.70, 'pendente', '2025-10-03 04:05:12', 'cartao_credito'),
(17, 1, 'The Last of Us Part I (R$ 249.90)', 'PD202510030108061611', 1499.40, 'pendente', '2025-10-03 04:08:06', 'pix');

-- --------------------------------------------------------

--
-- Estrutura para tabela `vendas`
--

CREATE TABLE `vendas` (
  `id_venda` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL,
  `data_venda` date NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `vendas`
--

INSERT INTO `vendas` (`id_venda`, `id_produto`, `quantidade`, `valor_total`, `data_venda`, `id_usuario`, `created_at`) VALUES
(1, 9, 4, 999.60, '2025-10-01', 1, '2025-10-01 03:26:30'),
(2, 1, 3, 0.00, '2025-10-01', 5, '2025-10-01 03:49:55'),
(3, 3, 2, 0.00, '2025-10-01', 5, '2025-10-01 03:53:32'),
(4, 8, 4, 519.60, '2025-10-01', 5, '2025-10-01 03:53:41'),
(5, 9, 2, 499.80, '2025-10-01', 5, '2025-10-01 05:19:21'),
(6, 9, 2, 499.80, '2025-10-01', 5, '2025-10-01 22:40:09'),
(7, 2, 33, 0.00, '2025-10-01', 5, '2025-10-01 22:40:34'),
(8, 3, 23, 0.00, '2025-10-01', 5, '2025-10-01 22:40:47'),
(9, 12, 2, 399.80, '2025-10-01', 5, '2025-10-01 22:41:17'),
(10, 19, 4, 1199.60, '2025-10-01', 5, '2025-10-02 01:34:45'),
(11, 15, 3, 899.70, '2025-10-01', 5, '2025-10-02 02:30:44'),
(12, 19, 2, 599.80, '2025-10-03', 5, '2025-10-03 03:59:30'),
(13, 21, 4, 1119.60, '2025-10-03', 14, '2025-10-03 04:09:05'),
(14, 22, 2, 499.80, '2025-10-03', 14, '2025-10-03 04:09:25');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `carrinho`
--
ALTER TABLE `carrinho`
  ADD PRIMARY KEY (`id_item`);

--
-- Índices de tabela `catalogo`
--
ALTER TABLE `catalogo`
  ADD PRIMARY KEY (`idProduto`);

--
-- Índices de tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  ADD PRIMARY KEY (`id_pagamento`),
  ADD KEY `id_pedido` (`id_pedido`);

--
-- Índices de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD PRIMARY KEY (`id_item_pedido`),
  ADD KEY `id_pedido` (`id_pedido`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD UNIQUE KEY `numero_pedido` (`numero_pedido`);

--
-- Índices de tabela `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`id_venda`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `carrinho`
--
ALTER TABLE `carrinho`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `catalogo`
--
ALTER TABLE `catalogo`
  MODIFY `idProduto` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de tabela `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  MODIFY `id_pagamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  MODIFY `id_item_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `vendas`
--
ALTER TABLE `vendas`
  MODIFY `id_venda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `historico_pagamentos`
--
ALTER TABLE `historico_pagamentos`
  ADD CONSTRAINT `historico_pagamentos_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`);

--
-- Restrições para tabelas `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD CONSTRAINT `itens_pedido_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
