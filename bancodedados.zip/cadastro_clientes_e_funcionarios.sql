-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03/10/2025 às 07:28
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cadastro clientes e funcionarios`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastro clientes`
--

CREATE TABLE `cadastro clientes` (
  `idCliente` int(7) NOT NULL,
  `nomecompletoCliente` varchar(50) NOT NULL,
  `emailCliente` varchar(65) NOT NULL,
  `telefoneCliente` varchar(28) NOT NULL,
  `senhaCliente` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cadastro clientes`
--

INSERT INTO `cadastro clientes` (`idCliente`, `nomecompletoCliente`, `emailCliente`, `telefoneCliente`, `senhaCliente`) VALUES
(1, 'artur', 'artur@gmail.com', '12313414', '1234'),
(2, 'Pablo Gonçalves Santos', 'pablogs3@gmail.com', '108104184', '1234567'),
(3, 'Gabriel Oliveira Santos', 'gabrielolv@gmail.com', '12341514', '1234567'),
(7, 'Gabriel Jesus Oliveira', 'gabriel@gmail.com', '12412414', '1234567'),
(10, 'Amanda Silva Oliveira', 'amanda@gmail.com', '84912471914', '1234567');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastro funcionários`
--

CREATE TABLE `cadastro funcionários` (
  `idFuncionario` int(7) NOT NULL,
  `nomecompletoFuncionario` varchar(50) NOT NULL,
  `emailCorporativo` varchar(100) NOT NULL,
  `telefoneFuncionario` varchar(28) NOT NULL,
  `senhaFuncionario` varchar(100) NOT NULL,
  `cargoFuncao` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cadastro funcionários`
--

INSERT INTO `cadastro funcionários` (`idFuncionario`, `nomecompletoFuncionario`, `emailCorporativo`, `telefoneFuncionario`, `senhaFuncionario`, `cargoFuncao`) VALUES
(1, 'adsada', 'adsadad@spike.com', '12313', '123', 'Administrador'),
(3, 'pablo gonçalves santos', 'pablogs@gmail.com', '12313123', '1234', 'Atendente'),
(4, 'Thierry Souza Matos Santos', 'th@spike.com', '124123', '123', 'Gerente de Vendas'),
(5, 'Pablo Gonçalves Santos', 'loboxmaker@spike.com', '11940075122', '1234', 'Administrador'),
(6, 'gabriel', 'biel@spike.com', '1248713213', '123', 'Estoquista'),
(7, 'Pablo Gonçalves Santos', 'pablogss@spike.com', '78148713931', '12345678', 'Administrador'),
(8, 'Pablo Gonçalves Santos', 'pablogs2@spike.com', '1239814971', '1234567', 'Administrador'),
(9, 'Pablo Gonçalves Santos', 'pablogs3@spike.com', '12412414', '1234567', 'Administrador'),
(12, 'Ana Oliveira Souza', 'ana@spike.com', '9751931981', '1234567', 'Vendedor'),
(14, 'Thierry Souza Matos Santos', 'ths@spike.com', '1192738233', '1234567', 'Administrador');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cadastro clientes`
--
ALTER TABLE `cadastro clientes`
  ADD PRIMARY KEY (`idCliente`),
  ADD UNIQUE KEY `emailCliente` (`emailCliente`);

--
-- Índices de tabela `cadastro funcionários`
--
ALTER TABLE `cadastro funcionários`
  ADD PRIMARY KEY (`idFuncionario`),
  ADD UNIQUE KEY `emailCorporativo` (`emailCorporativo`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cadastro clientes`
--
ALTER TABLE `cadastro clientes`
  MODIFY `idCliente` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `cadastro funcionários`
--
ALTER TABLE `cadastro funcionários`
  MODIFY `idFuncionario` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
